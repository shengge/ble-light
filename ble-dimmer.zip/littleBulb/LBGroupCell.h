//
//  LBGroupCell.h
//  littleBulb
//
//  Created by yy on 13-5-5.
//
//

#import <UIKit/UIKit.h>

@interface LBGroupCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutlet UISwitch *cellSwitch;

@end
