//
//  LBGroupCell.m
//  littleBulb
//
//  Created by yy on 13-5-5.
//
//

#import "LBGroupCell.h"

@implementation LBGroupCell

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
